from __future__ import annotations
import os
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

load_dotenv(BASE_DIR / ".env")

ALLOWED_EXTENSIONS = {"txt", "pdf", "png", "jpg", "jpeg", "gif", "csv", "xlsx", "docx"}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024

USERS = {"admin": "changeme"}

def create_app() -> Flask:
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.config.update(
        SECRET_KEY=os.getenv("SECRET_KEY", "dev-secret-key").encode(),
        MAX_CONTENT_LENGTH=MAX_CONTENT_LENGTH,
        UPLOAD_FOLDER=str(UPLOAD_DIR),
    )

    @app.route("/")
    def index():
        if session.get("user"):
            return redirect(url_for("dashboard"))
        return redirect(url_for("login"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            if USERS.get(username) == password:
                session["user"] = username
                flash("Welcome back!", "success")
                return redirect(url_for("dashboard"))
            flash("Invalid credentials.", "error")
        return render_template("login.html")

    @app.route("/logout")
    def logout():
        session.pop("user", None)
        flash("Signed out.", "info")
        return redirect(url_for("login"))

    def _allowed(filename: str) -> bool:
        return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

    @app.route("/dashboard")
    def dashboard():
        if not session.get("user"):
            return redirect(url_for("login"))
        files = sorted(os.listdir(app.config["UPLOAD_FOLDER"]))
        return render_template("dashboard.html", files=files)

    @app.route("/upload", methods=["POST"])
    def upload():
        if not session.get("user"):
            return ("Unauthorized", 401)
        f = request.files.get("file")
        if not f or f.filename == "":
            flash("No file selected.", "error")
            return redirect(url_for("dashboard"))
        if not _allowed(f.filename):
            flash("File type not allowed.", "error")
            return redirect(url_for("dashboard"))
        filename = secure_filename(f.filename)
        f.save(UPLOAD_DIR / filename)
        flash(f"Uploaded {filename}.", "success")
        return redirect(url_for("dashboard"))

    @app.route("/uploads/<path:filename>")
    def uploaded_file(filename):
        if not session.get("user"):
            return ("Unauthorized", 401)
        return send_from_directory(app.config["UPLOAD_FOLDER"], filename, as_attachment=True)

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 8000)), debug=True)
